public class Main {
    public static void main(String[] args) {
    int a;
        for (a=1;a<=8;a++)
            System.out.println("Selamat Datang");
 }
}
